FONT_FILES = {
    "Alagard Font.lua",
    "Aseprite Font.lua",
    "Aseprite Mini Font.lua",
    "RaccoonSerif Font.lua",
    "Strange Script Font.lua"
}